﻿using System;

namespace NetStandardLib
{
    public class Helper
    {
        public static DateTime GetDate() => DateTime.Now;
    }
}
