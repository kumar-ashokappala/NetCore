﻿using System;

namespace ConsoleAppCore
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(NetStandardLib.Helper.GetDate());
        }
    }
}
