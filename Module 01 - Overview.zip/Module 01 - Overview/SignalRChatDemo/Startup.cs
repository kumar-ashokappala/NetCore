﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using SignalRChatDemo.Hubs;

namespace SignalRChatDemo
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            // Adds support to SignalR
            services.AddSignalR();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // Configure file server middleware to run the static files (index.html)
            app.UseFileServer();

            // Configure SignalR and map the chat hub to route: /chat
            app.UseSignalR(routerBuilder =>
            {
                routerBuilder.MapHub<ChatHub>("/chat");

            });
        }
    }
}
