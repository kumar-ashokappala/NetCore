﻿using System;

namespace CoreRuntimeOptionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Hello, I am a .NET Core App and loaded from {System.Runtime.InteropServices.RuntimeInformation.OSDescription}");
        }
    }
}
