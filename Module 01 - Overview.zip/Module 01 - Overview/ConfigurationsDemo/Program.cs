﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.IO;

namespace ConfigurationsDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        private static Dictionary<string, string> _appConfigs = new Dictionary<string, string>
        {
            { "emailSettings:server", "smtp.example.com.dictionary" },
            { "emailSettings:from", "John.Doe@example.com.dictionary" }
        };

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost
            .CreateDefaultBuilder(args)
            .UseStartup<Startup>()
            .ConfigureAppConfiguration((hostingContext, config) =>
            {
                config.SetBasePath(Directory.GetCurrentDirectory());
                config.AddInMemoryCollection(_appConfigs);
                config.AddJsonFile("app_configs.json", optional: false, reloadOnChange: false);
                config.AddXmlFile("app_configs.xml", optional: false, reloadOnChange: false);
                config.AddIniFile("app_configs.ini", optional: true, reloadOnChange: true);
                config.AddCommandLine(args);
            });
    }
}
