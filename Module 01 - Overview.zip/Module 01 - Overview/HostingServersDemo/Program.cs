﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.HttpSys;
using System;
using System.Linq;

namespace HostingServersDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            // Builds the default web host builder which used Kesterl by default
            var hostBuilder = WebHost.CreateDefaultBuilder(args).UseStartup<Startup>();

            // Here we enable the use of HTTP.sys web server if we supplied --EnableHttpSys command argument
            // Run this command to use Kestrel:  dotnet run 
            // Run this command to use HTTP.sys: dotnet run --EnableHttpSys
            if (args.Any(argument => argument.Equals("--EnableHttpSys", StringComparison.InvariantCultureIgnoreCase)))
            {
                hostBuilder.UseHttpSys(options =>
                {
                    options.Authentication.Schemes = AuthenticationSchemes.NTLM;
                    options.Authentication.AllowAnonymous = true;
                    options.MaxConnections = null;
                    options.MaxRequestBodySize = 30000000;
                });
            }

            return hostBuilder;
        }
    }
}
